# STOCK-PREDICTION-USING-SVM-REGRESSION

API Call for fetching the company stock code is
http://d.yimg.com/autoc.finance.yahoo.com/autoc?query="............"&region=1&lang=en&callback=YAHOO.Finance.SymbolSuggest.ssCallback
Replace the "............." by company search query
API Call for downloading stock history prices from yahoo is
http://chart.finance.yahoo.com/table.csv?s="............."&a=10&b=20&c=2016&d=11&e=20&f=2016&g=d&ignore=.csv
Enter the company code in "............."
Code demonstration at:
https://www.youtube.com/watch?v=dIIIa0mljJo
